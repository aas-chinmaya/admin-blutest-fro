// const express = require('express');
// const router = express.Router();
// const {fetchBugsByAssignedTo,getBugsByTaskRef,downloadBugsByAssigneeAndProject,getAllBugByProjectIdAndMemberId,downloadBugsByProject,createBug,resolveBug,getallbugs,getallbugByProjectId,getbugBybug_id}= require('../../Controller/BugController/bugController');
// const validateToken=require("../../middlewares/authMiddleware");
// const multer = require("multer");
// const path = require("path");
// const fs = require("fs");

// // Ensure "uploads/bugs" folder exists
// const uploadDir = path.join(__dirname, "../../uploads/bugs");
// if (!fs.existsSync(uploadDir)) {
//   fs.mkdirSync(uploadDir, { recursive: true }); // recursive ensures nested folders are created
// }

// // Storage configuration
// const storage = multer.diskStorage({
//   destination: function (req, file, cb) {
//     cb(null, uploadDir);
//   },
//   filename: function (req, file, cb) {
//     const uniqueName = Date.now() + path.extname(file.originalname); // e.g., 1758625724354.png
//     cb(null, uniqueName);
//   },
// });

// const upload = multer({ storage });

// router.post('/create', upload.single("bugImage"), createBug);
// router.get("/task/:taskRef", getBugsByTaskRef);
// // router.post('/create', createBug);
// router.put('/resolve/:bug_id', resolveBug);
// router.get('/getallbugs', getallbugs);
// router.get('/getallbugByProjectId/:projectId', getallbugByProjectId);
// router.get('/getbugBybug_id/:bug_id', getbugBybug_id);
// // GET /api/bugs/assigned/:assignedTo
// router.get('/assigned/:assignedTo', fetchBugsByAssignedTo);
//  router.get('/download/:projectId', downloadBugsByProject);
// router.get('/download-by-assignee/:projectId/:assignedTo',downloadBugsByAssigneeAndProject );
// router.get('/getbugbyprojectandbmemberid/:projectId/:memberId',getAllBugByProjectIdAndMemberId);
// module.exports = router;



const express = require('express');
const multer = require("multer");
const path = require("path");
const router = express.Router();
// const multer = require("multer");
// const path = require("path");
const fs = require("fs");
const {fetchBugsByAssignedTo,downloadBugAttachment,downloadBugsByAssigneeAndProject,getAllBugByProjectIdAndMemberId,downloadBugsByProject,createBug,editBug,resolveBug,getallbugs,getallbugByProjectId,getbugBybug_id}= require('../../Controller/BugController/bugController');
const validateToken=require("../../middlewares/authMiddleware");
// Ensure "uploads/bugs" folder exists
const uploadDir = path.join(__dirname, "../../uploads/bugs");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true }); // recursive ensures nested folders are created
}
 
// Storage configuration
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + path.extname(file.originalname); // e.g., 1758625724354.png
    cb(null, uniqueName);
  },
});
 
const upload = multer({ storage });
 
// const upload = multer({ storage: storage });
// router.post('/create', createBug);
router.post('/create', upload.single("bugImage"), createBug);
router.put("/editbug/:bug_id", upload.single("bugImage"), editBug);
router.put('/resolve/:bug_id', resolveBug);
router.get('/getallbugs', getallbugs);
router.get('/getallbugByProjectId/:projectId', getallbugByProjectId);
router.get('/getbugBybug_id/:bug_id', getbugBybug_id);
// GET /api/bugs/assigned/:assignedTo
router.get('/assigned/:assignedTo', fetchBugsByAssignedTo);
 router.get('/download/:projectId', downloadBugsByProject);
router.get('/download-by-assignee/:projectId/:assignedTo',downloadBugsByAssigneeAndProject );
router.get('/getbugbyprojectandbmemberid/:projectId/:memberId',getAllBugByProjectIdAndMemberId);
// router.get("/attachment/:bug_id", viewAttachment);
// router.get('/uploads/bugs/:filename', viewAttachment);
// router.get("/uploads/bugs/:filePath", viewAttachment);
router.get("/:bugId/download", downloadBugAttachment);
module.exports = router;
 