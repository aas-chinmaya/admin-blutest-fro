const express = require('express');
const router = express.Router();
const clientController = require('../../Controller/ClientController/clientController');
const multer = require('multer');
const validateToken=require("../../middlewares/authMiddleware")

const storage = multer.memoryStorage();
const upload = multer({ storage });

router.post('/clientOnboard', upload.array('fileData',5),validateToken, clientController.createClient);
router.get('/getAllClients',validateToken, clientController.getAllClients);
router.get('/downloadClientFile/:clientId/:fileIndex',validateToken, clientController.downloadClientFile);
router.get('/getClientById/:clientId',validateToken, clientController.getClientById);
router.put('/updateClient/:clientId', upload.array('fileData',5),validateToken, clientController.updateClient);
router.delete('/softeDeleteClient/:clientId', validateToken,clientController.softeDeleteClient);
// router.get('/clients/in-progress-projects', clientController.getClientsWithInProgressProjects);
// router.get('/clients/onboarded-last-3-months', clientController.getClientsOnboardedLast3Months);


router.get('/insights', validateToken,clientController.getClientInsights);


module.exports = router;

