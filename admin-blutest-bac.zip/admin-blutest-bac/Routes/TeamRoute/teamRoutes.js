const express = require('express');
const router = express.Router();
const teamController = require('../../Controller/TeamController/teamController');
const validateToken=require("../../middlewares/authMiddleware")

// Create
router.post('/createteam',validateToken, teamController.createTeam);

// Read All
router.get('/getallteams',validateToken,teamController.getAllTeams);
//get all team by user id
router.get('/user/:userId', teamController.getTeamsByUserId);
// Read One
router.get('/getteamid/:teamId', validateToken,teamController.getTeamById);

// Update
router.put('/updateteam/:teamId',validateToken, teamController.updateTeam);

// Delete (Soft)
router.delete('/deleteteam/:teamId',validateToken, teamController.deleteTeam);

router.get('/getallteamsbyprojectid/:projectId', validateToken,teamController.getAllTeamsByProjectId);

// router.get('/teammembers/:teamLeadId ', teamController.getTeamMembersByTeamLeadId );


router.get('/teamlead/:teamId', validateToken,teamController.getTeamMembersExcludingLead);

router.get('/team-leads',validateToken,teamController.getAllTeamLeadDetails);
 

router.get('/members/by-project/:projectId', teamController.getTeamMembersByProjectId);





router.delete('/soft-delete/:teamId', teamController.softDeleteTeam);
 
module.exports = router;
