const express = require('express');
const router = express.Router();
const { createService, getServices,getServiceById,deleteService,updateService} = require('../../Controller/MasterController/serviceController');

router.post('/createservice', createService);
router.get('/getservice', getServices);
router.get('/getServiceById/:id', getServiceById);
router.put('/updateservice/:id', updateService);
router.delete('/deleteservice/:id',deleteService);

module.exports = router;
