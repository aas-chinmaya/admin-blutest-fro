const express = require('express');
const router = express.Router();
const {updateTaskStatusById,updateReviewStatus,getTasksByMemberIdAndProjectId,exportTasks,getTasksByprojectId,getTaskCounts,getTasksByMemberId,  getProjectTaskSummary,linkBugToTask,reviewTask, getTasksByAssignee,getTasksByDeadline,getAllTask, assignTask ,getAllTasks,getTaskById,updateTask,deleteTask,deleteTaskPermanent,updateTaskStatus} = require('../../Controller/TaskController/taskController');
const validateToken=require("../../middlewares/authMiddleware")


router.post('/assign',validateToken, assignTask);
router.get('/getall',validateToken, getAllTasks);
router.get('/member/:memberId', validateToken,getTasksByMemberId);
router.get('/getbyid/:task_id',validateToken, getTaskById);
router.put('/update/:task_id',validateToken, updateTask);
router.delete('/delete/:task_id',validateToken, deleteTask);
router.delete('/deletepermanent/:task_id',validateToken, deleteTaskPermanent);
router.put('/tasks/:task_id/status',validateToken, updateTaskStatus);
router.get('/tasks',validateToken, getAllTask);


router.get('/bydeadline', validateToken,getTasksByDeadline);

router.get('/by-assignee', validateToken,getTasksByAssignee);
router.post('/review/:task_id',validateToken, reviewTask);
router.post('/:task_id/link-bug', validateToken,linkBugToTask);
router.get('/project-summary/:project_id', validateToken,getProjectTaskSummary);

router.get('/project-tasks/:projectId', getTasksByprojectId);

router.get('/counts', validateToken,getTaskCounts);

router.put('/update-status/:task_id', updateTaskStatusById);
router.put('/review-status/:task_id', updateReviewStatus);

router.post("/export-tasks", exportTasks);
router.get('/getalltaskbyprojectid/:memberId/:projectId', getTasksByMemberIdAndProjectId);
module.exports = router;
