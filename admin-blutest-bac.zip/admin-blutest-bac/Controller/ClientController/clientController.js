const Client = require('../../Model/ClientModel/clientModel');
const Project = require('../../Model/ProjectModel/projectModel');

  
exports.createClient = async (req, res) => {
  try {
    const {
      clientName,
      industryType,
      contactPersonName,
      contactEmail,
      contactNo,
      address,
      onboardingDate,
      website,
    } = req.body;
 
    const fileData = (req.files || []).map(file => ({
      data: file.buffer,
      contentType: file.mimetype,
      fileName: file.originalname
    }));
 
    // Get the total number of clients
    const clientCount = await Client.countDocuments();
    const nextId = clientCount + 1;
    const clientId = `CLIENT-${String(nextId).padStart(3, '0')}`;
 
    const newClient = new Client({
      clientId,
      clientName,
      industryType,
      contactPersonName,
      contactEmail,
      contactNo,
      address,
      onboardingDate,
      website,
      fileData,
      Onboardedstatus: 'onboard'
    });
 
    await newClient.save();
 
    res.status(201).json({
      success: true,
      message: 'Client onboarded successfully',
      client: newClient
    });
 
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error onboarding client',
      error: error.message
    });
  }
};

exports.getAllClients = async (req, res) => {
  try {
    const clients = await Client.find({ isDeleted: false }).select('-fileData').sort({ createdAt: -1 });
    const totalClients = clients.length;

    res.status(200).json({
      success: true,
      message: 'Clients fetched successfully',
      totalClients,
      clients
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching clients',
      error: error.message
    });
  }
};

// Download a client file
exports.downloadClientFile = async (req, res) => {
    try {
        const {clientId, fileIndex} = req.params;

        if (!clientId || !fileIndex) {
            return res.status(400).json({ success: false, message: 'Invalid request' });
        }

        const client = await Client.findOne({ clientId });

        if (!client) {
            return res.status(404).json({ success: false, message: 'Client not found' });
        }

        if (!client.fileData || !client.fileData.length) {
            return res.status(404).json({ message: 'No files found for this client' });
        }

        const index= parseInt(fileIndex,10);
        if(isNaN(index) || index < 0 || index >= client.fileData.length) {
            return res.status(404).json({ message: 'Invalid file index' });
        }

        const file = client.fileData[index];

        res.set({
            'Content-Type': file.contentType,
            'Content-Disposition': `attachment; filename=${clientId}_file_${index + 1}`
        });
        
        res.send(file.data);
    } catch (error) {
        res.status(500).json({ message: 'Error downloading file', error: error.message });
    }
};


exports.getClientById= async (req, res) => {
    try {
        const {clientId}= req.params;

        if (!clientId) {
            return res.status(400).json({ success: false, message: 'Invalid request' });
        }

        const client = await Client.findOne({ clientId });

        if (!client) {
            return res.status(404).json({ success: false, message: 'Client not found' });
        }
        // const fileDownloadLinks = (client.fileData || []).map((_, index) => {
        //     return `${req.protocol}://${req.get('host')}/api/client/downloadClientFile/${clientId}/${index}`;
        // });

        const fileDownloadLinks = (client.fileData || []).map((file, index) => ({
            name: file.fileName || `file_${index + 1}`,
            url: `${req.protocol}://${req.get('host')}/api/client/downloadClientFile/${clientId}/${index}`
        }));
        
        res.status(200).json({
            success: true,
            message:'Client fetched successfully',
            client:{
                clientId: client.clientId,
                clientName: client.clientName,
                industryType: client.industryType,
                contactPersonName: client.contactPersonName,
                contactEmail: client.contactEmail,
                contactNo: client.contactNo,
                address: client.address,
                onboardingDate: client.onboardingDate,
                website: client.website,
                createdAt: client.createdAt,
                updatedAt: client.updatedAt,
                fileDownloadLinks 
            }
        })
    } catch (error) {
        res.status(500).json({ success: false, message: 'Error fetching client', error: error.message });
    }
}


exports.updateClient= async (req, res) => {
    try {
        const {clientId}= req.params;

        if (!clientId) {
            return res.status(400).json({ success: false, message: 'Invalid request' });
        }
        const existingClient = await Client.findOne({ clientId });
        if (!existingClient) {
            return res.status(404).json({ success: false, message: 'Client not found' });
        }
        const {
            clientName,
            industryType,
            contactPersonName,
            contactEmail,
            contactNo,
            address,
            onboardingDate,
            website,
        } = req.body;
        
        const fileData= (req.files || []).map(file=>({
            data: file.buffer,
            contentType: file.mimetype
        }));
        
        if(clientName) existingClient.clientName= clientName;
        if(industryType) existingClient.industryType= industryType;
        if(contactPersonName) existingClient.contactPersonName= contactPersonName;
        if(contactEmail) existingClient.contactEmail= contactEmail;
        if(contactNo) existingClient.contactNo= contactNo;
        if(address) existingClient.address= address;
        if(onboardingDate) existingClient.onboardingDate= onboardingDate;
        if(website) existingClient.website= website;
        if(fileData.length>0) existingClient.fileData= fileData;

        await existingClient.save();
        res.status(200).json({ success: true, message: 'Client updated successfully', client: existingClient });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Error updating client', error: error.message });
    }
}

exports.softeDeleteClient = async (req, res) => {
    try {
        const {clientId}= req.params;
        
        const client= await Client.findOne({clientId});

        if(!client){
            return res.status(404).json({ success: false, message: 'Client not found' });
        }

        client.isDeleted= true;
        await client.save();

        res.status(200).json({ success: true, message: 'Client deleted successfully' });

    } catch (error) {
        res.status(500).json({ success: false, message: 'Error deleting client', error: error.message });
    }
}


exports.getClientInsights = async (req, res) => {
  try {
    // Step 1: Get all "In Progress" projects with projectId, projectName, clientId
    const inProgressProjects = await Project.find({ status: 'In Progress' }).select('projectId projectName clientId');

    // Group projects by clientId
    const clientProjectsMap = {};
    inProgressProjects.forEach(project => {
      if (!clientProjectsMap[project.clientId]) {
        clientProjectsMap[project.clientId] = [];
      }
      clientProjectsMap[project.clientId].push({
        projectId: project.projectId,
        projectName: project.projectName
      });
    });

    // Step 2: Get unique clientIds from those projects
    const clientIds = Object.keys(clientProjectsMap);

    // Step 3: Get full client details
    const clients = await Client.find({
      clientId: { $in: clientIds },
      isDeleted: false
    });

    // Step 4: Attach projects and project count to client data
    const clientsWithInProgressProjects = clients.map(client => {
      const projects = clientProjectsMap[client.clientId] || [];
      return {
        ...client.toObject(),
        projects,
        projectCount: projects.length
      };
    });

    // Step 5: Get clients onboarded in last 3 months
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);

    const recentClients = await Client.find({
      onboardingDate: { $gte: threeMonthsAgo },
      isDeleted: false
    }).sort({ onboardingDate: -1 });

    // Step 6: Final Response
    return res.status(200).json({
      success: true,
      clientsWithInProgressProjects: {
        total: clientsWithInProgressProjects.length,
        clients: clientsWithInProgressProjects
      },
      clientsOnboardedLast3Months: {
        total: recentClients.length,
        clients: recentClients
      }
    });

  } catch (error) {
    console.error('Error fetching client insights:', error);
    return res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};



