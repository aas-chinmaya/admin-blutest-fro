
const Bug = require('../../Model/BugModel/Bug');
const Task = require('../../Model/TaskModel/Task');
const Notification = require('../../Model/NotificationModel/notificationModel');
const Project=require("../../Model/ProjectModel/projectModel")
const Team=require("../../Model/TeamModel/Team")
const ExcelJS = require('exceljs');
const pushTaskHistory = require('../../utils/pushTaskHistory');
const path = require("path");
const fs = require("fs");
const mime = require("mime-types");

 
// exports.createBug = async (req, res) => {

//   try {

//     const { title, description, task_id, priority, deadline } = req.body;
 
//     // Step 1: Validate Task

//     const task = await Task.findOne({ task_id });

//     if (!task) return res.status(404).json({ message: 'Task not found' });
 
//     // Step 2: Prepare Bug data (no task status update)

//     const bugData = {

//       title,

//       description,

//       priority,

//       deadline,

//       taskRef: task.task_id,

//       assignedTo: task.memberId,

//       projectId: task.projectId,

//     };
 
//     //  Handle file upload if attachment exists

//     if (req.file) {

//       bugData.attachment = `uploads/bugs/${req.file.filename}`;

//     }
 
//     // Step 3: Create Bug

//     const newBug = await Bug.createBugWithId(bugData);
 
//     // Step 4: Push history (mention bug created but don’t alter task status)

//     await pushTaskHistory(task.task_id, {

//       action: 'Bug Reported',

//       reviewStatus: 'BugReported',

//       bug_id: newBug.bug_id,

//       bugTitle: newBug.title,

//       bugStatus: newBug.status

//     });
 
//     // Step 5: Notify the assignee

//     const notification = new Notification({

//       recipientId: task.memberId.toString(),

//       message: `A bug has been reported for your task "${task.title}": "${title}".`,

//       link: `/bugs/${newBug.bug_id}`

//     });

//     await notification.save();
 
//     res.status(201).json({

//       message: 'Bug created successfully (task status unchanged)',

//       bug: newBug

//     });
 
//   } catch (err) {

//     console.error("Error creating bug:", err);

//     res.status(500).json({ message: 'Server error', error: err.message });

//   }

// };
exports.createBug = async (req, res) => {
  try {
    const { title, description, task_id, subtask_id, priority, deadline } = req.body;

    // Step 1: Validate Task
    const task = await Task.findOne({ task_id });
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }

    // Step 2: Prepare Bug data
    const bugData = {
      title,
      description,
      priority,
      deadline,
      taskRef: task.task_id,
      assignedTo: task.memberId,
      projectId: task.projectId,
    };

    // Step 3: Include subtaskRef only if provided
    if (subtask_id && subtask_id.trim() !== "") {
      bugData.subtaskRef = subtask_id;
    }

    // Step 4: Handle file upload (optional)
    if (req.file) {
      bugData.attachment = `uploads/bugs/${req.file.filename}`;
    }

    // Step 5: Create Bug
    const newBug = await Bug.createBugWithId(bugData);

    // Step 6: Push task/subtask history (no status change)
    await pushTaskHistory(task.task_id, {
      action: "Bug Reported",
      reviewStatus: "BugReported",
      bug_id: newBug.bug_id,
      bugTitle: newBug.title,
      bugStatus: newBug.status,
      ...(subtask_id ? { subtask_id } : {}), // only if exists
    });

    // Step 7: Notify assignee
    const notification = new Notification({
      recipientId: task.memberId.toString(),
      message: subtask_id
        ? `A bug has been reported for subtask "${subtask_id}" in task "${task.title}": "${title}".`
        : `A bug has been reported for your task "${task.title}": "${title}".`,
      link: `/bugs/${newBug.bug_id}`,
    });

    await notification.save();

    // Step 8: Send response
    res.status(201).json({
      message: subtask_id
        ? "Bug created successfully for subtask (task status unchanged)"
        : "Bug created successfully for task (task status unchanged)",
      bug: newBug,
    });
  } catch (err) {
    console.error("Error creating bug:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
};
 
exports.editBug = async (req, res) => {
  try {
    const { bug_id } = req.params;
    const { title, description, priority, deadline, status } = req.body;

    // Step 1: Find the bug
    const bug = await Bug.findOne({ bug_id });
    if (!bug) {
      return res.status(404).json({ message: "Bug not found" });
    }

    // Step 2: Update bug fields
    if (title) bug.title = title;
    if (description) bug.description = description;
    if (priority) bug.priority = priority;
    if (deadline) bug.deadline = deadline;
    if (status) bug.status = status;

    //  Handle file update (optional attachment)
    if (req.file) {
      bug.attachment = `uploads/bugs/${req.file.filename}`;
    }

    await bug.save();

    // Step 3: Push history for update
    await pushTaskHistory(bug.taskRef, {
      action: "Bug Updated",
      bug_id: bug.bug_id,
      bugTitle: bug.title,
      bugStatus: bug.status,
    });

    // Step 4: Notify assignee (optional)
    const notification = new Notification({
      recipientId: bug.assignedTo.toString(),
      message: `Bug "${bug.title}" has been updated.`,
      link: `/bugs/${bug.bug_id}`,
    });
    await notification.save();

    res.status(200).json({
      message: "Bug updated successfully",
      bug,
    });
  } catch (err) {
    console.error("Error updating bug:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
};









exports.downloadBugAttachment = async (req, res) => {
 try {
    const { bugId } = req.params; // this is bug_id like "BUG-001"\
    console.log(bugId)

    // Find the bug by bug_id
    const bug = await Bug.findOne({ bug_id: bugId });
    if (!bug) {
      return res.status(404).json({ message: "Bug not found" });
    }

    if (!bug.attachment) {
      return res.status(404).json({ message: "No attachment for this bug" });
    }

    // Full path to the attachment
    const filePath = path.resolve(`./${bug.attachment}`);

    // Check if file exists
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "Attachment file not found on server" });
    }

    // Send file for download
    res.download(filePath, path.basename(filePath), (err) => {
      if (err) {
        console.error("Download error:", err);
        return res.status(500).json({ message: "Error downloading file" });
      }
    });

  } catch (error) {
    console.error("Server error:", error);
    res.status(500).json({ message: "Server error" });
  }
};

exports.resolveBug = async (req, res) => {
  try {
    const { bug_id } = req.params;
    const { delayReason, resolutionNote } = req.body;
 
    // Step 1: Find the bug
    const bug = await Bug.findOne({ bug_id });
    if (!bug) {
      return res.status(404).json({ message: 'Bug not found' });
    }
 
    if (bug.status === 'Resolved') {
      return res.status(400).json({ message: 'Bug is already resolved' });
    }
 
    // Step 2: resolutionNote is mandatory
    if (!resolutionNote || resolutionNote.trim() === '') {
      return res.status(400).json({ message: 'Resolution note is required to resolve this bug' });
    }
 
    const now = new Date();
 
    // Step 3: Handle deadline & delayReason
    if (bug.deadline) {
      const deadlineDate = new Date(bug.deadline);
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const deadlineDay = new Date(deadlineDate.getFullYear(), deadlineDate.getMonth(), deadlineDate.getDate());
 
      if (today > deadlineDay) { // If today is after the deadline
        if (!delayReason || delayReason.trim() === '') {
          return res.status(400).json({
            message: 'Bug is resolved after the deadline. Please provide a delay reason.'
          });
        }
        bug.isLate = true;
        bug.delayReason = delayReason;
      }
    }
 
    // Step 4: Update bug status
    bug.status = 'Resolved';
    bug.resolvedAt = now;
    bug.resolutionNote = resolutionNote;
    await bug.save();
 
    // Step 5: Get the associated task
    const task = await Task.findOne({ task_id: bug.taskRef });
    if (!task) {
      return res.status(404).json({ message: 'Associated task not found' });
    }
 
    // Step 6: Update taskHistory for this bug
    const historyEntry = task.taskHistory.find(h => h.bug_id === bug.bug_id);
    if (historyEntry) {
      historyEntry.bugStatus = bug.status;
      historyEntry.reviewStatus = task.reviewStatus || 'InReview';
      historyEntry.action = "Bug Resolved";
      historyEntry.timestamp = now;
    } else {
      task.taskHistory.push({
        action: "Bug Resolved",
        timestamp: now,
        reviewStatus: task.reviewStatus || 'InReview',
        bug_id: bug.bug_id,
        bugTitle: bug.title,
        bugStatus: bug.status
      });
    }
 
    // Step 7: Check if all bugs for this task are resolved
    const unresolvedBugs = await Bug.find({
      taskRef: task.task_id,
      status: { $ne: 'Resolved' }
    });
 
    let taskUpdated = null;
 
    // This part is now omitted as per your request
    // if (unresolvedBugs.length === 0) {
    //   // All bugs resolved → Task Completed
    //   task.status = 'Completed';
    //   task.completedAt = now;
    //   task.reviewStatus = 'InReview';
    //   taskUpdated = task;
 
    //   // Notify Team Lead
    //   const team = await Team.findOne({ projectId: task.projectId, isDeleted: false });
    //   if (team && team.teamLeadId) {
    //     const notification = new Notification({
    //       recipientId: team.teamLeadId.toString(),
    //       message: `Task "${task.title}" has been marked as completed after all bugs were resolved.`,
    //       link: `/tasks/${task.task_id}`
    //     });
    //     await notification.save();
    //   }
    // }
 
    await task.save();
 
    res.status(200).json({
      message: `Bug ${bug.bug_id} resolved successfully and task history updated`,
      bug,
      taskUpdated
    });
 
  } catch (err) {
    console.error("Error resolving bug:", err);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};


 
// exports.resolveBug = async (req, res) => {
//   try {
//     const { bug_id } = req.params;
//     const { delayReason, resolutionNote } = req.body;

//     // Step 1: Find the bug
//     const bug = await Bug.findOne({ bug_id });
//     if (!bug) {
//       return res.status(404).json({ message: 'Bug not found' });
//     }

//     if (bug.status === 'Resolved') {
//       return res.status(400).json({ message: 'Bug is already resolved' });
//     }

//     // Step 2: resolutionNote is mandatory
//     if (!resolutionNote || resolutionNote.trim() === '') {
//       return res.status(400).json({ message: 'Resolution note is required to resolve this bug' });
//     }

//     const now = new Date();

//     // Step 3: Handle deadline & delayReason
//     if (bug.deadline) {
//       const deadlineDate = new Date(bug.deadline);
//       const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
//       const deadlineDay = new Date(deadlineDate.getFullYear(), deadlineDate.getMonth(), deadlineDate.getDate());

//       if (today > deadlineDay) { // If today is after the deadline
//         if (!delayReason || delayReason.trim() === '') {
//           return res.status(400).json({
//             message: 'Bug is resolved after the deadline. Please provide a delay reason.'
//           });
//         }
//         bug.isLate = true;
//         bug.delayReason = delayReason;
//       }
//     }

//     // Step 4: Update bug status
//     bug.status = 'Resolved';
//     bug.resolvedAt = now;
//     bug.resolutionNote = resolutionNote;
//     await bug.save();

//     // Step 5: Get the associated task
//     const task = await Task.findOne({ task_id: bug.taskRef });
//     if (!task) {
//       return res.status(404).json({ message: 'Associated task not found' });
//     }

//     // Step 6: Update taskHistory for this bug
//     const historyEntry = task.taskHistory.find(h => h.bug_id === bug.bug_id);
//     if (historyEntry) {
//       historyEntry.bugStatus = bug.status;
//       historyEntry.reviewStatus = task.reviewStatus || 'InReview';
//       historyEntry.action = "Bug Resolved";
//       historyEntry.timestamp = now;
//     } else {
//       task.taskHistory.push({
//         action: "Bug Resolved",
//         timestamp: now,
//         reviewStatus: task.reviewStatus || 'InReview',
//         bug_id: bug.bug_id,
//         bugTitle: bug.title,
//         bugStatus: bug.status
//       });
//     }

//     // Step 7: Check if all bugs for this task are resolved
//     const unresolvedBugs = await Bug.find({
//       taskRef: task.task_id,
//       status: { $ne: 'Resolved' }
//     });

//     let taskUpdated = null;

//     if (unresolvedBugs.length === 0) {
//       // All bugs resolved → Task Completed
//       task.status = 'Completed';
//       task.completedAt = now;
//       task.reviewStatus = 'InReview';
//       taskUpdated = task;

//       // Notify Team Lead
//       const team = await Team.findOne({ projectId: task.projectId, isDeleted: false });
//       if (team && team.teamLeadId) {
//         const notification = new Notification({
//           recipientId: team.teamLeadId.toString(),
//           message: `Task "${task.title}" has been marked as completed after all bugs were resolved.`,
//           link: `/tasks/${task.task_id}`
//         });
//         await notification.save();
//       }
//     } else {
//       // Partial resolution
//       task.reviewStatus = 'InReview';
//     }

//     await task.save();

//     res.status(200).json({
//       message: `Bug ${bug.bug_id} resolved successfully and task history updated`,
//       bug,
//       taskUpdated
//     });

//   } catch (err) {
//     console.error("Error resolving bug:", err);
//     res.status(500).json({ message: 'Server error', error: err.message });
//   }
// };


exports.getallbugs = async (req, res) => {
  try {
    const bugs = await Bug.find().sort({ createdAt: -1 });
    res.status(200).json(bugs);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};



 

exports.getallbugByProjectId = async (req, res) => {
  try {
    const { projectId } = req.params;

    // 1. Fetch bugs for the project
    const bugs = await Bug.find({ projectId }).sort({ dueDate: 1 });

    // 2. Fetch all teams linked to this project
    const teams = await Team.find({ projectId, isDeleted: false });

    // 3. Combine all team members from all teams (if multiple teams per project)
    const allMembers = teams.flatMap(team => team.teamMembers);

    // 4. Enrich each bug with assignedToDetails + attachment link
    const enrichedBugs = bugs.map(bug => {
      const assignedMember = allMembers.find(member => member.memberId === bug.assignedTo);

      // Add attachmentLinks array
      let attachmentLinks = [];
      if (bug.attachment) {
        attachmentLinks.push(
          `https://${req.get("host")}/api/bugs/${bug.bug_id}/download`
        );
      }

      return {
        ...bug.toObject(),
        assignedToDetails: assignedMember
          ? {
              _id: assignedMember._id,
              memberId: assignedMember.memberId,
              memberName: assignedMember.memberName,
              email: assignedMember.email,
              role: assignedMember.role,
            }
          : null,
        attachmentLinks, // Added attachment download link
      };
    });

    res.json(enrichedBugs);
  } catch (err) {
    console.error('Error in getallbugByProjectId:', err);
    res.status(500).json({ error: err.message });
  }
};


exports.getbugBybug_id = async (req, res) => {
  try {
    const { bug_id } = req.params;

    // 1. Fetch a single bug by bug_id
    const bug = await Bug.findOne({ bug_id }).sort({ dueDate: 1 });

    if (!bug) {
      return res.status(404).json({ message: "No bug found with this ID" });
    }

    // 2. Extract projectId from the bug and fetch teams
    const projectId = bug.projectId;
    const teams = await Team.find({ projectId, isDeleted: false });
    const allMembers = teams.flatMap((team) => team.teamMembers);

    // 3. Enrich bug with assignedToDetails
    const assignedMember = allMembers.find(
      (member) => member.memberId.toString() === bug.assignedTo.toString()
    );

    // 4. Add attachment link if exists
    let attachmentLinks = [];
    if (bug.attachment) {
      attachmentLinks.push(
        `https://${req.get("host")}/api/bugs/${bug.bug_id}/download`
      );
    }

    const enrichedBug = {
      ...bug.toObject(),
      assignedToDetails: assignedMember
        ? {
            _id: assignedMember._id,
            memberId: assignedMember.memberId,
            memberName: assignedMember.memberName,
            email: assignedMember.email,
            role: assignedMember.role,
          }
        : null,
      attachmentLinks,
    };

    res.json({ success: true, data: enrichedBug });
  } catch (err) {
    console.error("Error in getbugBybug_id:", err);
    res.status(500).json({ success: false, error: err.message });
  }
};





exports.fetchBugsByAssignedTo = async (req, res) => {
  try {
    const { assignedTo } = req.params;

    if (!assignedTo) {
      return res.status(400).json({ message: 'assignedTo parameter is required' });
    }

    // Fetch bugs by assignedTo
    const bugs = await Bug.find({ assignedTo }).sort({ createdAt: -1 });

    if (!bugs.length) {
      return res.status(404).json({ message: 'No bugs found for the given employee' });
    }

    // Extract unique projectIds from these bugs
    const projectIds = [...new Set(bugs.map(bug => bug.projectId))];

    // Fetch teams related to these projects
    const teams = await Team.find({ projectId: { $in: projectIds }, isDeleted: false });

    // Flatten all team members
    const allMembers = teams.flatMap(team => team.teamMembers);

    // Fetch all taskIds from bugs to batch query tasks
    const taskIds = bugs.map(bug => bug.taskRef);
    const tasks = await Task.find({ task_id: { $in: taskIds } });

    // Map for quick lookup
    const taskMap = new Map(tasks.map(task => [task.task_id, task.reviewStatus]));

    // Fetch project names
    const projects = await Project.find({ projectId: { $in: projectIds } });
    const projectMap = new Map(projects.map(project => [project.projectId, project.projectName]));

    // Enrich bugs with assignedToDetails, reviewStatus, and projectName
    const enrichedBugs = bugs.map(bug => {
      const assignedMember = allMembers.find(member => member.memberId === bug.assignedTo);

      return {
        ...bug.toObject(),
        assignedToDetails: assignedMember ? {
          _id: assignedMember._id,
          memberId: assignedMember.memberId,
          memberName: assignedMember.memberName,
          email: assignedMember.email,
          role: assignedMember.role
        } : null,
        reviewStatus: taskMap.get(bug.taskRef) || 'N/A',
        projectName: projectMap.get(bug.projectId) || 'Unknown'
      };
    });

    res.status(200).json({ success: true, data: enrichedBugs });
  } catch (error) {
    console.error('Error fetching bugs:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

 
 exports.downloadBugsByProject = async (req, res) => {
  const { projectId } = req.params;
 
  try {
    // Step 1: Get all bugs by projectId
    const bugs = await Bug.find({ projectId }).sort({ createdAt: 1 });
 
    // Step 2: Get all teams in that project
    const teams = await Team.find({ projectId, isDeleted: false });
 
    // Step 3: Merge all teamMembers
    const allMembers = teams.flatMap(team => team.teamMembers);
 
    // Step 4: Enrich bugs with assignedTo details and task title
    const enrichedBugs = await Promise.all(
      bugs.map(async (bug) => {
        const assignedMember = allMembers.find(
          member => member.memberId === bug.assignedTo
        );
 
        const task = await Task.findOne({ task_id: bug.taskRef });
 
        return {
          ...bug.toObject(),
          assignedToDetails: assignedMember
            ? {
                memberId: assignedMember.memberId,
                memberName: assignedMember.memberName,
              }
            : {
                memberId: bug.assignedTo,
                memberName: 'Not Found',
              },
          deadline: bug.deadline,
          taskTitle: task?.title || 'N/A',  // Use task title instead of taskRef
          reviewStatus: task?.reviewStatus || 'N/A',
        };
      })
    );
 
    // Step 5: Generate Excel
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Bugs');
 
    worksheet.columns = [
      { header: 'Bug ID', key: 'bug_id', width: 15 },
      { header: 'Title', key: 'title', width: 30 },
      { header: 'Description', key: 'description', width: 40 },
      { header: 'Task Title', key: 'taskTitle', width: 30 }, // replaced Task Ref
      { header: 'Assigned To', key: 'assignedToName', width: 25 },
      { header: 'Priority', key: 'priority', width: 12 },
      { header: 'Deadline', key: 'deadline', width: 20 },
      { header: 'Review Status', key: 'reviewStatus', width: 20 },
      { header: 'Status', key: 'status', width: 12 },
      { header: 'Created At', key: 'createdAt', width: 25 },
      { header: 'Resolved At', key: 'resolvedAt', width: 25 },
    ];
 
    enrichedBugs.forEach(bug => {
      worksheet.addRow({
        bug_id: bug.bug_id,
        title: bug.title,
        description: bug.description,
        taskTitle: bug.taskTitle,
        assignedToName: bug.assignedToDetails?.memberName || 'Unknown',
        priority: bug.priority,
        status: bug.status,
        createdAt: bug.createdAt ? bug.createdAt.toISOString() : '',
        resolvedAt: bug.resolvedAt ? bug.resolvedAt.toISOString() : '',
        deadline: bug.deadline
          ? new Date(bug.deadline).toISOString().split('T')[0]
          : 'N/A',
        reviewStatus: bug.reviewStatus,
      });
    });
 
    // Step 6: Send file
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    res.setHeader(
      'Content-Disposition',
      `attachment; filename=bugs_${projectId}.xlsx`
    );
 
    await workbook.xlsx.write(res);
    res.status(200).end();
  } catch (error) {
    console.error('Error exporting bugs:', error);
    res.status(500).json({
      message: 'Failed to export bugs',
      error: error.message,
    });
  }
};
 


exports.downloadBugsByAssigneeAndProject = async (req, res) => {
  const { assignedTo, projectId } = req.params;
 
  try {
    // Step 1: Find bugs for the specific user and project
    const bugs = await Bug.find({ assignedTo, projectId }).sort({ createdAt: 1 });
 
    if (bugs.length === 0) {
      return res
        .status(404)
        .json({ message: 'No bugs found for this user in this project' });
    }
 
    // Step 2: Get all teams in the project containing the member
    const teams = await Team.find({
      projectId,
      isDeleted: false,
      'teamMembers.memberId': assignedTo,
    });
 
    // Step 3: Extract member details
    let assignedMember = null;
    for (const team of teams) {
      const match = team.teamMembers.find(
        (member) => member.memberId === assignedTo
      );
      if (match) {
        assignedMember = match;
        break;
      }
    }
 
    const assignedToDetails = assignedMember
      ? {
          memberId: assignedMember.memberId,
          memberName: assignedMember.memberName,
        }
      : {
          memberId: assignedTo,
          memberName: 'Not Found',
        };
 
    // Step 4: Setup Excel file
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Bugs by Assignee');
 
    worksheet.columns = [
      { header: 'Bug ID', key: 'bug_id', width: 15 },
      { header: 'Title', key: 'title', width: 30 },
      { header: 'Description', key: 'description', width: 40 },
      { header: 'Task Title', key: 'taskTitle', width: 30 }, //  Replaced Task Ref
      { header: 'Assigned To Name', key: 'assignedToName', width: 25 },
      { header: 'Priority', key: 'priority', width: 12 },
      { header: 'Deadline', key: 'deadline', width: 20 },
      { header: 'Task Review Status', key: 'reviewStatus', width: 20 },
      { header: 'Status', key: 'status', width: 12 },
      { header: 'Created At', key: 'createdAt', width: 25 },
      { header: 'Resolved At', key: 'resolvedAt', width: 25 },
    ];
 
    // Step 5: Add bug data
    for (const bug of bugs) {
      // Get the corresponding task to fetch reviewStatus and title
      const task = await Task.findOne({ task_id: bug.taskRef });
 
      worksheet.addRow({
        bug_id: bug.bug_id,
        title: bug.title,
        description: bug.description,
        taskTitle: task?.title || 'N/A', //  Task title instead of ref
        assignedToName: assignedToDetails.memberName,
        priority: bug.priority,
        status: bug.status,
        createdAt: bug.createdAt?.toISOString(),
        resolvedAt: bug.resolvedAt ? bug.resolvedAt.toISOString() : 'N/A',
        deadline: bug.deadline
          ? new Date(bug.deadline).toISOString().split('T')[0]
          : 'N/A',
        reviewStatus: task?.reviewStatus || 'N/A',
      });
    }
 
    // Step 6: Send the Excel file
    res.setHeader(
      'Content-Type',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    res.setHeader(
      'Content-Disposition',
      `attachment; filename=bugs_${projectId}_${assignedTo}.xlsx`
    );
 
    await workbook.xlsx.write(res);
    res.status(200).end();
  } catch (error) {
    console.error('Error exporting bugs by assignee and project:', error);
    res.status(500).json({
      message: 'Failed to export bugs',
      error: error.message,
    });
  }
};





exports.getAllBugByProjectIdAndMemberId = async (req, res) => {
    try {
    const { projectId, memberId } = req.params;

    if (!projectId || !memberId) {
      return res.status(400).json({ message: "projectId and memberId are required" });
    }

    // Fetch bugs for this project assigned to this member
    const bugs = await Bug.find({ projectId, assignedTo: memberId }).sort({ deadline: 1 });

    if (!bugs.length) {
      return res.status(404).json({ message: "No bugs found for this project and member" });
    }

    // Fetch teams linked to this project
    const teams = await Team.find({ projectId, isDeleted: false });
    const allMembers = teams.flatMap(team => team.teamMembers);

    // Enrich bugs with member details + attachment link
    const enrichedBugs = bugs.map(bug => {
      const assignedMember = allMembers.find(
        member => member.memberId.toString() === bug.assignedTo.toString()
      );

      let attachmentLinks = [];
      if (bug.attachment) {
        attachmentLinks.push(
          `https://${req.get("host")}/api/bugs/${bug.bug_id}/download`
        );
      }

      return {
        ...bug.toObject(),
        assignedToDetails: assignedMember
          ? {
              _id: assignedMember._id,
              memberId: assignedMember.memberId,
              memberName: assignedMember.memberName,
              email: assignedMember.email,
              role: assignedMember.role,
            }
          : null,
        attachmentLinks,
      };
    });

    res.status(200).json({ success: true, data: enrichedBugs });
  } catch (err) {
    console.error('Error in getAllBugByProjectIdAndMemberId:', err);
    res.status(500).json({ success: false, error: err.message });
  }
};




exports.getBugsByTaskRef = async (req, res) => {
  try {
    const { taskRef } = req.params;
 
    // Find all bugs matching the given taskRef
    const bugs = await Bug.find({ taskRef }).sort({ createdAt: -1 });
 
    if (!bugs || bugs.length === 0) {
      return res.status(404).json({
        success: false,
        message: `No bugs found for taskRef: ${taskRef}`,
      });
    }
 
    res.status(200).json({
      success: true,
      count: bugs.length,
      data: bugs,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: err.message,
    });
  }
};




