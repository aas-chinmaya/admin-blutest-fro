const mongoose = require('mongoose');
 
const contactSchema = new mongoose.Schema({
 contactId:{type: String, unique: true},
  fullName: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String, required: true },
  companyName: { type: String, required: true },
  designation: { type: String }, //  New field added here
  industry: { type: String },
  location: { type: String },
 Companylocation: { type: String },
  serviceInterest: [{ type: String }],
  referralSource: { type: String },
  message: { type: String, required: true },
  status: { type: String, enum: ['Pending', 'Accepted', 'Rejected'], default: 'Pending' },
  internalNotes: { type: String },
  assignedAdmin: { type: String },
  feedback: { type: String },
   isDeleted: { type: Boolean, default: false },
 
}, { timestamps: true });
 
module.exports = mongoose.model('Contact', contactSchema);