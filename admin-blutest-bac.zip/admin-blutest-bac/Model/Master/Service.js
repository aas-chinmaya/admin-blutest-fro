const mongoose = require('mongoose');

const ServiceSchema = new mongoose.Schema({
  serviceId: { type: String,  unique: true },
  name: { type: String, required: true },
  description: String,
  basePrice: { type: Number, required: true, min: 0 },
}, { timestamps: true });
ServiceSchema.statics.createServiceWithId = async function (serviceData) {
  const lastService = await this.findOne().sort({ createdAt: -1 });

  let nextId = 1;
  if (lastService && lastService.serviceId) {
    const lastNum = parseInt(lastService.serviceId.split('-')[1]);
    nextId = lastNum + 1;
  }

  const serviceId = `SRV-${String(nextId).padStart(3, '0')}`;

  const newService = new this({
    serviceId,
    ...serviceData
  });

  return newService.save();
};

module.exports = mongoose.model('Service', ServiceSchema)

