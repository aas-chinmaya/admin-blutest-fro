// Model/CalenderModel/ShowCause.js
const mongoose = require('mongoose');
 
const showCauseSchema = new mongoose.Schema({
   showCauseId: {
    type: String,
   
  },
  meetingId: { type: String, required: true, unique: true },
  reason: { type: String, required: true },
  submittedBy: { type: String, required: true }, // email or userId
  submittedAt: { type: Date, default: Date.now },
   status: {
    type: String,
    enum: ['Pending', 'Approved', 'Rejected'],
    default: 'Pending',
  },
});
 
module.exports = mongoose.model('ShowCause', showCauseSchema);
 