const crypto = require('crypto');
const bcrypt = require('bcrypt');

module.exports = (UserModel, SessionModel, OtpVerificationModel) => {
  // Verify OTP and create a session
  async function verifyOTPAndCreateSession(email, inputOTP, deviceInfo, ipAddress) {
    // Find OTP record
    const otpDoc = await OtpVerificationModel.findOne({ email });
    if (!otpDoc) {
      throw new Error('OTP not found or expired');
    }

    // Check if account is frozen
    if (otpDoc.freezeUntil && otpDoc.freezeUntil > Date.now()) {
      throw new Error(`Account frozen until ${new Date(otpDoc.freezeUntil).toLocaleString()}`);
    }

    // Verify OTP
    const isValid = await bcrypt.compare(inputOTP, otpDoc.loginOTP);
    if (!isValid) {
      otpDoc.failedAttempts += 1;
      if (otpDoc.failedAttempts >= 3) {
        otpDoc.freezeUntil = Date.now() + 15 * 60 * 1000; // Freeze for 15 minutes
      }
      await otpDoc.save();
      throw new Error('Invalid OTP');
    }

    // OTP verified, mark as used
    await OtpVerificationModel.updateOne(
      { _id: otpDoc._id },
      { $set: { isUsed: true, usedAt: Date.now() } }
    );

    // Verify user exists in HRMS DB
    const user = await UserModel.findOne({ email });
    if (!user) {
      throw new Error('User not found');
    }

    // Create session
    const session = new SessionModel({
      email,
      sessionToken: crypto.randomBytes(32).toString('hex'),
      deviceInfo: deviceInfo || 'Unknown',
      ipAddress: ipAddress || 'Unknown',
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    });

    try {
      await session.save();
      return { session, user };
    } catch (error) {
      if (error.code === 11000) {
        throw new Error('Session token already exists');
      }
      throw error;
    }
  }

  // Get session with user details
  async function getSessionWithUserDetails(sessionToken) {
    // Find session
    const session = await SessionModel.findOne({ sessionToken });
    if (!session) {
      throw new Error('Session not found');
    }

    // Fetch user details from HRMS DB
    const user = await UserModel.findOne({ email: session.email });
    if (!user) {
      throw new Error('User not found');
    }

    return {
      session,
      user: {
        _id: user._id,
        email: user.email || null,
        username: user.username || null,
        fullName: user.fullName || null,
        role: user.role || null,
        userId: user.userId || null,
      },
    };
  }

  // Delete session (for logout)
  async function deleteSession(sessionToken) {
    const session = await SessionModel.findOneAndDelete({ sessionToken });
    if (!session) {
      throw new Error('Session not found');
    }
    return session;
  }

  async function deleteAllSessions(sessionToken) {
    const sessions = await SessionModel.deleteMany({ sessionToken });
    if (!sessions) {
      throw new Error('Session not found');
    }
    const  result=await SessionModel.deleteMany({ email:sessions.email });
    return {deletedCount:result.deletedCount,email:sessions.email};
  }

  return { verifyOTPAndCreateSession, getSessionWithUserDetails, deleteSession ,deleteAllSessions};
};