
 const path = require('path');
const Mom = require('../../Model/CalenderModel/momModel');
const Project=require('../../Model/ProjectModel/projectModel')
const  generateMomPDF  = require('../../utils/pdfGenerator');
const UserToken = require("../../Model/CalenderModel/userTokenModel");
const fs = require('fs');



const {google,oAuth2Client} = require('../../Config/google');
 exports.getAllMOMs = async (req, res) => {
  try {
    const moms = await Mom.find({}).sort({ date: -1 }); // Optional: sort by latest first
    res.status(200).json({
      message: ' All MOMs fetched successfully',
      count: moms.length,
      data: moms,
    });
  } catch (err) {
    console.error(' Error fetching all MOMs:', err);
    res.status(500).json({ message: 'Failed to fetch MOMs', error: err.message });
  }
};

exports.getMOMById = async (req, res) => {
  try {
    const { momId } = req.params;
 
    const mom = await Mom.findOne({ momId });
    if (!mom) {
      return res.status(404).json({ message: ' MOM not found with given ID' });
    }
 
    res.status(200).json({
      message: 'MOM fetched successfully',
      data: mom,
    });
  } catch (err) {
    console.error(' Error fetching MOM by ID:', err);
    res.status(500).json({ message: 'Failed to fetch MOM', error: err.message });
  }
};


exports.createMOM = async (req, res) => {
  try {
    const {
      meetingId,
      agenda,
      meetingMode,
      duration,
      summary,
      notes,
      createdBy,
      status //
    } = req.body;
 
    if (!meetingId || !agenda || !meetingMode || !duration || !summary || !notes || !createdBy || !status) {
      return res.status(400).json({ message: 'Missing required fields' });
    }
 
    const signatureBuffer = req.file?.buffer || null;
    const signatureMimeType = req.file?.mimetype || '';
 
    const users = await UserToken.find();
    let meetingDetails = null;
 
    for (const user of users) {
      oAuth2Client.setCredentials(user.tokens);
      const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
 
      try {
        const event = await calendar.events.get({
          calendarId: 'primary',
          eventId: meetingId
        });
 
        if (event && event.data) {
          meetingDetails = event.data;
          break;
        }
      } catch (err) {
        continue;
      }
    }
 
    if (!meetingDetails) {
      return res.status(404).json({ message: 'Meeting not found' });
    }
 
    const eventStart = new Date(meetingDetails.start.dateTime || meetingDetails.start.date);
    const formattedDate = eventStart.toISOString().split('T')[0];
    const formattedTime = eventStart.toTimeString().split(' ')[0].replace(/:/g, '-');
    const momId = `AAS-IT-MOM-${formattedDate}-${formattedTime}`;
 
    const baseUrl = `${req.protocol}s://${req.get('host')}`;
    const attachmentUrl = `${baseUrl}/api/mom/view/${momId}`;
 
    // Save signature to folder
    let signatureRelativePath = null;
    if (signatureBuffer) {
      const allowedTypes = {
        'image/jpeg': 'jpg',
        'image/png': 'png'
      };
      const extension = allowedTypes[signatureMimeType];
      if (!extension) {
        return res.status(400).json({ message: 'Unsupported signature file type' });
      }
 
      const signatureFolder = path.join('uploads', 'signatures');
      const signatureFilename = `${momId}-signature.${extension}`;
      const signatureDir = path.resolve(__dirname, '../../', signatureFolder);
 
      if (!fs.existsSync(signatureDir)) {
        fs.mkdirSync(signatureDir, { recursive: true });
      }
 
      const signaturePath = path.join(signatureDir, signatureFilename);
      fs.writeFileSync(signaturePath, signatureBuffer);
      signatureRelativePath = path.posix.join('uploads', 'signatures', signatureFilename);
    }
 
    // Check for existing MoM
    let existingMom = await Mom.findOne({ momId });
 
    if (existingMom) {
      // Update existing draft/final
      existingMom.agenda = agenda;
      existingMom.meetingMode = meetingMode;
      existingMom.duration = duration;
      existingMom.summary = summary;
      existingMom.notes = notes;
      existingMom.createdBy = createdBy;
      existingMom.signature = signatureRelativePath || existingMom.signature;
      existingMom.status = status;
      existingMom.attachmentUrl = attachmentUrl;
 
      if (status === 'final') {
        const pdfBuffer = await generateMomPDF(existingMom.toObject());
        const pdfFilename = `${momId}.pdf`;
        const pdfDir = path.resolve(__dirname, '../../uploads/moms');
        const pdfPath = path.join(pdfDir, pdfFilename);
        if (!fs.existsSync(pdfDir)) {
          fs.mkdirSync(pdfDir, { recursive: true });
        }
        fs.writeFileSync(pdfPath, pdfBuffer);
        existingMom.pdfUrl = `${baseUrl}/api/mom/view/${momId}`;
      }
 
      await existingMom.save();
      return res.status(200).json({
        message: status === 'draft' ? 'Draft updated' : 'MoM finalized successfully',
        mom: existingMom,
        ...(existingMom.pdfUrl && { pdfUrl: existingMom.pdfUrl })
      });
    }
 
    // Create new MoM
    const momData = {
      momId,
      meetingId,
      date: formattedDate,
      time: formattedTime.replace(/-/g, ':'),
      agenda,
      meetingMode,
      duration,
      participants: (meetingDetails.attendees || []).map(a => a.email),
      summary,
      notes,
      createdBy,
      signature: signatureRelativePath,
      attachmentUrl,
      status
    };
 
    if (status === 'final') {
      const pdfBuffer = await generateMomPDF(momData);
      const pdfFilename = `${momId}.pdf`;
      const pdfDir = path.resolve(__dirname, '../../uploads/moms');
      const pdfPath = path.join(pdfDir, pdfFilename);
      if (!fs.existsSync(pdfDir)) {
        fs.mkdirSync(pdfDir, { recursive: true });
      }
      fs.writeFileSync(pdfPath, pdfBuffer);
      momData.pdfUrl = `${baseUrl}/api/mom/view/${momId}`;
    }
 
    const savedMom = await Mom.create(momData);
 
     return res.status(200).json({
      message: status === 'draft' ? 'MoM saved as draft' : 'MoM created successfully',
      mom: savedMom
    });
 
  } catch (err) {
    console.error('Error:', err);
    return res.status(500).json({ message: 'Failed to create MOM', error: err.message });
  }
};

exports.downloadMOM = async (req, res) => {
  try {
    console.log(`Fetching MoM for momId: ${req.params.momId}`);
    const mom = await Mom.findOne({ momId: req.params.momId });
    if (!mom) {
      console.log(`No document found for momId: ${req.params.momId}`);
      return res.status(404).json({ message: 'MoM document not found' });
    }
 
    console.log(`Generating PDF for momId: ${req.params.momId}`);
    const pdfBuffer = await generateMomPDF({
      momId: mom.momId,
      date: mom.date,
      time: mom.time,
      agenda: mom.agenda,
      meetingMode: mom.meetingMode,
      duration: mom.duration,
      participants: mom.participants,
      summary: mom.summary,
      notes: mom.notes,
      createdBy: mom.createdBy,
      signature: mom.signature,
      pdfl: mom.pdf,
    });
 
    console.log(`Serving PDF for momId: ${req.params.momId}`);
    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename=MOM-${mom.momId}.pdf`
    });
    res.send(pdfBuffer);
  } catch (err) {
    console.error(' Error retrieving or generating PDF:', err);
    res.status(500).json({ message: 'Failed to retrieve or generate PDF', error: err.message });
  }
};



exports.viewMOM = async (req, res) => {
  try {
    const momId = req.params.momId;
 
    // 1. Check MOM status in DB
    const momRecord = await Mom.findOne({ momId });
 
    if (!momRecord) {
      return res.status(404).json({ message: "MoM record not found." });
    }
 
    // 2. Allow only if status is 'final'
    if (momRecord.status !== 'final') {
      return res.status(403).json({ message: "PDF is only available for finalized MoMs." });
    }
 
    // 3. Serve PDF if exists
    const pdfPath = path.resolve(process.cwd(), `uploads/moms/${momId}.pdf`);
    console.log('Serving PDF from:', pdfPath);
 
    if (!fs.existsSync(pdfPath)) {
      return res.status(404).json({ message: "PDF file not found on server." });
    }
 
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="${momId}.pdf"`);
    fs.createReadStream(pdfPath).pipe(res);
  } catch (error) {
    console.error('Error viewing MoM PDF:', error);
    res.status(500).json({ message: "Failed to view MoM PDF", error: error.message });
  }
};

exports.getMOMByMeetingId = async (req, res) => {

  try {

    const { meetingId } = req.params;
 
    if (!meetingId) {

      return res.status(400).json({ message: ' meetingId is required' });

    }
 
    const mom = await Mom.findOne({ meetingId });
 
    if (!mom) {

      return res.status(404).json({ message: ' MOM not found for this meetingId' });

    }
 
    res.status(200).json({

      message: 'MOM fetched successfully by meetingId',

      data: mom,

    });

  } catch (err) {

    console.error(' Error fetching MOM by meetingId:', err);

    res.status(500).json({ message: 'Failed to fetch MOM', error: err.message });

  }

};

exports.updateMOM = async (req, res) => {

  try {

    const { meetingId, agenda, meetingMode, duration, summary, notes, createdBy } = req.body;

    const signatureBuffer = req.file?.buffer || null;
 
    if (!meetingId) {

      return res.status(400).json({ message: ' meetingId is required to update MOM' });

    }
 
    //  Check if MOM already exists

    const existingMom = await Mom.findOne({ meetingId });

    if (!existingMom) {

      return res.status(404).json({ message: ' MOM not found for given meetingId' });

    }
 
    //  Try finding the event from any authorized user's calendar

    const users = await UserToken.find();

    let meetingDetails = null;
 
    for (const user of users) {

      oAuth2Client.setCredentials(user.tokens);

      const calendar = google.calendar({ version: 'v3', auth: oAuth2Client });
 
      try {

        const event = await calendar.events.get({

          calendarId: 'primary',

          eventId: meetingId

        });
 
        if (event && event.data) {

          meetingDetails = event.data;

          break;

        }

      } catch (err) {

        continue; // Skip to next user if this one fails

      }

    }
 
    if (!meetingDetails) {

      return res.status(404).json({ message: ' Meeting not found in any linked Google account' });

    }
 
    //  Format date and time from the meeting

    const eventStart = new Date(meetingDetails.start.dateTime || meetingDetails.start.date);

    const formattedDate = eventStart.toISOString().split('T')[0];

    const formattedTime = eventStart.toTimeString().split(' ')[0].replace(/:/g, '-');
 
    //  Build the update object

    const updatedFields = {

      agenda: agenda || existingMom.agenda,

      meetingMode: meetingMode || existingMom.meetingMode,

      duration: duration || existingMom.duration,

      summary: summary || existingMom.summary,

      notes: notes || existingMom.notes,

      createdBy: createdBy || existingMom.createdBy,

      date: formattedDate,

      time: formattedTime.replace(/-/g, ':'),

      participants: (meetingDetails.attendees || []).map(a => a.email),

    };
 
    if (signatureBuffer) {

      updatedFields.signature = signatureBuffer;

    }
 
    //  Perform the update

    const updatedMom = await Mom.findOneAndUpdate(

      { meetingId },

      updatedFields,

      { new: true }

    );
 
    return res.status(200).json({

      message: ' MOM updated successfully',
      meetingId,

      data: updatedMom,

    });

  } catch (err) {

    console.error(' Error updating MOM:', err);

    res.status(500).json({ message: 'Failed to update MOM', error: err.message });

  }

};


exports.createProjectMOM = async (req, res) => {
  try {
    const {
      projectName,
      meetingId,
      agenda,
      meetingMode,
      duration,
      summary,
      notes,
      createdBy,
      status // 'draft' or 'final'
    } = req.body;
 
    const signatureBuffer = req.file?.buffer || null;
    const signatureMimeType = req.file?.mimetype || '';
 
    if (!projectName || !meetingId || !agenda || !meetingMode || !duration || !summary || !notes || !createdBy || !status) {
      return res.status(400).json({ message: 'Missing required fields' });
    }
 
    const baseUrl = `${req.protocol}s://${req.get('host')}`;
    const now = new Date();
    const formattedDate = now.toISOString().split('T')[0];
    const formattedTime = now.toTimeString().split(' ')[0];
 
    // Handle signature upload
    let signatureRelativePath = null;
    if (signatureBuffer) {
      const allowedTypes = {
        'image/jpeg': 'jpg',
        'image/png': 'png'
      };
      const extension = allowedTypes[signatureMimeType];
      if (!extension) {
        return res.status(400).json({ message: 'Unsupported signature file type. Please upload .jpg or .png' });
      }
 
      const signatureFolder = path.join('uploads', 'signatures');
      const signatureFilename = `signature-${Date.now()}.${extension}`;
      const signatureDir = path.resolve(__dirname, '../../', signatureFolder);
 
      if (!fs.existsSync(signatureDir)) {
        fs.mkdirSync(signatureDir, { recursive: true });
      }
 
      const signaturePath = path.join(signatureDir, signatureFilename);
      fs.writeFileSync(signaturePath, signatureBuffer);
      signatureRelativePath = path.posix.join('uploads', 'signatures', signatureFilename);
    }
 
    //  Find existing MoM
    let existingMom = await Mom.findOne({ meetingId, projectName });
 
    if (existingMom) {
      if (existingMom.status === 'final') {
        return res.status(400).json({ message: 'Finalized MoM already exists. Cannot edit again.' });
      }
 
      //  Update existing draft (and finalize if requested)
      existingMom.agenda = agenda;
      existingMom.meetingMode = meetingMode;
      existingMom.duration = duration;
      existingMom.summary = summary;
      existingMom.notes = notes;
      existingMom.createdBy = createdBy;
      existingMom.signature = signatureRelativePath || existingMom.signature;
      existingMom.date = formattedDate;
      existingMom.time = formattedTime;
      existingMom.attachmentUrl = `${baseUrl}/api/mom/view/${existingMom.momId}`;
 
      if (status === 'final') {
        existingMom.status = 'final';
        const pdfBuffer = await generateMomPDF(existingMom.toObject());
 
        const pdfFilename = `${existingMom.momId}.pdf`;
        const pdfDir = path.resolve(__dirname, '../../uploads/moms');
        if (!fs.existsSync(pdfDir)) {
          fs.mkdirSync(pdfDir, { recursive: true });
        }
 
        const pdfPath = path.join(pdfDir, pdfFilename);
        fs.writeFileSync(pdfPath, pdfBuffer);
 
        existingMom.pdfUrl = `${baseUrl}/api/mom/view/${existingMom.momId}`;
      }
 
      await existingMom.save();
 
      return res.status(200).json({
        message: status === 'draft' ? 'Project MoM draft updated' : 'Project MoM finalized successfully',
        mom: existingMom,
        ...(existingMom.pdfUrl && { pdfUrl: existingMom.pdfUrl })
      });
    }
 
    // Create new only if none exists
    const projectCode = projectName.substring(0, 3).toUpperCase();
    const existingCount = await Mom.countDocuments({ momId: { $regex: `^AAS-MOM-${projectCode}-` } });
    const momNumber = String(existingCount + 1).padStart(3, '0');
    const momId = `AAS-MOM-${projectCode}-${momNumber}`;
    const attachmentUrl = `${baseUrl}/api/mom/view/${momId}`;
 
    const momData = {
      momId,
      meetingId,
      date: formattedDate,
      time: formattedTime,
      agenda,
      meetingMode,
      duration,
      participants: [],
      summary,
      notes,
      createdBy,
      projectName,
      signature: signatureRelativePath,
      attachmentUrl,
      status
    };
 
    if (status === 'final') {
      const pdfBuffer = await generateMomPDF(momData);
      const pdfFilename = `${momId}.pdf`;
      const pdfDir = path.resolve(__dirname, '../../uploads/moms');
      if (!fs.existsSync(pdfDir)) {
        fs.mkdirSync(pdfDir, { recursive: true });
      }
 
      const pdfPath = path.join(pdfDir, pdfFilename);
      fs.writeFileSync(pdfPath, pdfBuffer);
 
      momData.pdfUrl = `${baseUrl}/api/mom/view/${momId}`;
    }
 
    const savedMom = await Mom.create(momData);
 
    return res.status(200).json({
      message: status === 'draft' ? 'Project MoM saved as draft' : 'Project MoM finalized successfully',
      mom: savedMom,
      ...(momData.pdfUrl && { pdfUrl: momData.pdfUrl })
    });
 
  } catch (err) {
    console.error('Error creating Project MOM:', err);
    res.status(500).json({ message: 'Failed to create MOM', error: err.message });
  }
};
 
 

 

  
exports.getMoMByMomId = async (req, res) => {
  try {
    const { momId } = req.params;

    if (!momId) {
      return res.status(400).json({ message: 'momId is required' });
    }

    const mom = await Mom.findOne({ momId });

    if (!mom) {
      return res.status(404).json({ message: 'MoM not found' });
    }

    return res.status(200).json(mom);
  } catch (error) {
    console.error('Error fetching MoM by momId:', error);
    return res.status(500).json({ message: 'Server error' });
  }
};










exports.getMOMsByProjectId = async (req, res) => {
  try {
    const { projectId } = req.params;
 
    if (!projectId) {
      return res.status(400).json({ message: 'projectId is required' });
    }
 
    // Step 1: Get project with meetingIds
    const project = await Project.findOne({ projectId, isDeleted: false });
 
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }
 
    const meetingIds = project.meetingIds || [];
 
    if (meetingIds.length === 0) {
      return res.status(404).json({ message: 'No meetings found for this project' });
    }
 
    // Step 2: Fetch all MoMs linked to meetingIds
    const moms = await Mom.find({ meetingId: { $in: meetingIds } });
 
    if (!moms.length) {
      return res.status(404).json({ message: 'No MoMs found for this project' });
    }
 
    res.status(200).json({
      message: 'MoMs fetched successfully for project',
      data: moms,
    });
 
  } catch (err) {
    console.error('Error fetching MoMs by projectId:', err);
    res.status(500).json({ message: 'Failed to fetch MoMs', error: err.message });
  }
};