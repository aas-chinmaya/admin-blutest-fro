const BudgetEntity = require("../../Model/BudgetModel/BudgetEntity");

// ====================================
// Create Budget Entity
// ====================================
// exports.createBudgetEntity = async (req, res) => {
//   try {
//     const {
//       accountId,
//       categoryId,
//       name,
//       costType,
//       rate,
//       totalUnits,
//       totalCost,
//       currency,
//       createdBy,
//     } = req.body;

//     const newEntity = new BudgetEntity({
//       accountId,
//       categoryId,
//       name,
//       costType,
//       rate,
//       totalUnits,
//       totalCost,
//       currency,
//       history: [
//         {
//           action: "create",
//           changedBy: createdBy,
//           changes: req.body,
//         },
//       ],
//     });

//     await newEntity.save();

//     res.status(201).json({
//       success: true,
//       message: "Budget Entity created successfully",
//       data: newEntity,
//     });
//   } catch (error) {
//     console.error("Error creating budget entity:", error);
//     res.status(500).json({
//       success: false,
//       message: "Error creating budget entity",
//       error: error.message,
//     });
//   }
// };

exports.createBudgetEntity = async (req, res) => {
  try {
    const {
      accountId,
      categoryId,
      name,
      costType,
      rate,
      totalUnits,
      totalCost,
      currency,
      createdBy,
    } = req.body;

    const entity = new BudgetEntity({
      accountId,
      categoryId,
      name,
      costType,
      rate,
      totalUnits,
      totalCost,
      currency,
      history: [
        {
          action: "create",
          changedBy: createdBy,
          changes: JSON.stringify(req.body),
        },
      ],
    });

    await entity.save();

    res.status(201).json({
      success: true,
      message: "Budget Entity created successfully",
      data: entity,
    });
  } catch (error) {
    console.error("Error creating budget entity:", error);
    res.status(500).json({
      success: false,
      message: "Error creating budget entity",
      error: error.message,
    });
  }
};



// ====================================
// Get All Budget Entities (not deleted)
// ====================================
exports.getAllBudgetEntities = async (req, res) => {
  try {
    const entities = await BudgetEntity.find({ isDeleted: false })
      .populate("accountId", "accountName")
      .populate("categoryId", "categoryName");

    res.status(200).json({
      success: true,
      count: entities.length,
      data: entities,
    });
  } catch (error) {
    console.error("Error fetching budget entities:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching budget entities",
      error: error.message,
    });
  }
};

// ====================================
// Get Single Budget Entity by ID
// ====================================
exports.getBudgetEntityById = async (req, res) => {
  try {
    const entity = await BudgetEntity.findOne({
      _id: req.params.id,
      isDeleted: false,
    })
      .populate("accountId", "accountName")
      .populate("categoryId", "categoryName");

    if (!entity) {
      return res.status(404).json({
        success: false,
        message: "Budget Entity not found",
      });
    }

    res.status(200).json({
      success: true,
      data: entity,
    });
  } catch (error) {
    console.error("Error fetching budget entity:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching budget entity",
      error: error.message,
    });
  }
};

// ====================================
// Update Budget Entity
// ====================================
exports.updateBudgetEntity = async (req, res) => {
  try {
    const { editedBy } = req.body;

    const entity = await BudgetEntity.findOneAndUpdate(
      { _id: req.params.id, isDeleted: false },
      { ...req.body },
      { new: true }
    );

    if (!entity) {
      return res.status(404).json({
        success: false,
        message: "Budget Entity not found or deleted",
      });
    }

    // Add update record in history
    entity.history.push({
      action: "update",
      changedBy: editedBy,
      changes: req.body,
    });

    await entity.save();

    res.status(200).json({
      success: true,
      message: "Budget Entity updated successfully",
      data: entity,
    });
  } catch (error) {
    console.error("Error updating budget entity:", error);
    res.status(500).json({
      success: false,
      message: "Error updating budget entity",
      error: error.message,
    });
  }
};

// ====================================
// Soft Delete Budget Entity
// ====================================
exports.softDeleteBudgetEntity = async (req, res) => {
  try {
    const { deletedBy } = req.body;

    const entity = await BudgetEntity.findOneAndUpdate(
      { _id: req.params.id, isDeleted: false },
      { isDeleted: true, isActive: false },
      { new: true }
    );

    if (!entity) {
      return res.status(404).json({
        success: false,
        message: "Budget Entity not found or already deleted",
      });
    }

    entity.history.push({
      action: "delete",
      changedBy: deletedBy,
      changes: { isDeleted: true },
    });

    await entity.save();

    res.status(200).json({
      success: true,
      message: "Budget Entity deleted successfully (soft delete)",
      data: entity,
    });
  } catch (error) {
    console.error("Error deleting budget entity:", error);
    res.status(500).json({
      success: false,
      message: "Error deleting budget entity",
      error: error.message,
    });
  }
};


// Fetch all entities for a specific categoryId
exports.fetchAllEntitiesByCategoryId = async (req, res) => {
  try {
    const { categoryId } = req.params;

    if (!categoryId) {
      return res.status(400).json({
        success: false,
        message: "categoryId is required",
      });
    }

    const entities = await BudgetEntity.find({
      categoryId: categoryId,
      isDeleted: false,
    }).sort({ createdAt: -1 }); // latest first

    res.status(200).json({
      success: true,
      message: `Entities for category ${categoryId} fetched successfully`,
      data: entities,
    });
  } catch (error) {
    console.error("Error fetching entities by categoryId:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching entities",
      error: error.message,
    });
  }
};