

const express = require("express");
const router = express.Router();
const paymentController = require("../../Controller/CalenderController/paymentController");
const webhookController = require("../../Controller/CalenderController/webhookController");

router.post("/create-payment-link", paymentController.createPaymentLink);
router.post("/webhook/razorpay", express.json(), webhookController.handleWebhook);
// POST: /api/payment/update-statuscode
// router.post("/create-payment-link", paymentController.createPaymentLink);
router.post("/send-statuscode", paymentController.updatePaymentStatusCode);
router.get('/statuscheck/:contactId', paymentController.getPaidStatusByContactId);
router.get('/paymentdetails/:contactId', paymentController.getPaymentLinkByContactId)
router.get("/razorpay/payment/:paymentId", paymentController.getPaymentDetailsFromRazorpay);

router.post("/status/:paymentId", paymentController.updatePaymentStatusByPaymentId);


module.exports = router;

