const express = require("express");
const router = express.Router();
const budgetEntityController = require("../../Controller/BudgetController/BudgetEntityController");

// Create
router.post("/createbudgetentity", budgetEntityController.createBudgetEntity);

// Get All
router.get("/getallbudgetentity", budgetEntityController.getAllBudgetEntities);
router.get("/fetchAllEntitiesByCategoryId/:categoryId", budgetEntityController.fetchAllEntitiesByCategoryId);

// Get One by ID
router.get("/getbudgetentitybyid/:id", budgetEntityController.getBudgetEntityById);

// Update
router.put("/updatebudgetentity/:id", budgetEntityController.updateBudgetEntity);

// Soft Delete
router.delete("/deletebudgetentity/:id", budgetEntityController.softDeleteBudgetEntity);

module.exports = router;
