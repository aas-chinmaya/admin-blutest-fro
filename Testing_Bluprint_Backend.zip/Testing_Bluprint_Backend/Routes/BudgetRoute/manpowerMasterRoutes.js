const express = require("express");
const router = express.Router();
const {
  createManpower,
  getAllManpower,
  getManpowerById,
  updateManpower,
  deleteManpower,
} = require("../../Controller/BudgetController/manpowerMasterController");

router.post("/createmanpower", createManpower); // Create
router.get("/getallmanpower", getAllManpower); // Get all
router.get("/getmanpowerbyid/:manpowerId", getManpowerById); // Get by ID
router.put("/updatemanpower/:manpowerId", updateManpower); // Update
router.delete("/deletemanpower/:manpowerId", deleteManpower); // Soft delete

module.exports = router;
