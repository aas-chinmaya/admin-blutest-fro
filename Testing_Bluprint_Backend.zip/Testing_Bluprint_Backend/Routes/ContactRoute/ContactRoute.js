const express = require('express');
const router = express.Router();
const contactController = require('../../Controller/ContactController/contactController');

router.post('/createcontact', contactController.createContact);
// Get all contacts
router.get('/getallcontact', contactController.getAllContacts);

// Get contact by contactId
router.get('/getcontactby/:contactId', contactController.getContactById);

// Update contact by contactId
router.put('/updatecontact/:contactId', contactController.updateContact);

// Soft delete contact
router.delete('/deletecontact/:contactId', contactController.deleteContact);

// GET route for fetching approved contacts
router.get('/approved', contactController.getApprovedContacts);

module.exports = router;
